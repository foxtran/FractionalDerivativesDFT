#ifdef __cplusplus
extern "C" {
#endif

double hyp2F2(double a1, double a2, double b1, double b2, double z);

#ifdef __cplusplus
}
#endif
